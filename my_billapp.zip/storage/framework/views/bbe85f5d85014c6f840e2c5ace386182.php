<header>
    <nav class="container">
        <div class="logo">
            <h1>My<span>BillApp</span></h1>
        </div>
        <div class="menu-toggle">
            <i class="fas fa-bars"></i>
        </div>
        <ul class="nav-menu">
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#how-it-works">How It Works</a></li>
            <li><a href="#testimonials">Testimonials</a></li>
            <li><a href="#contact" class="btn btn-outline">Contact Us</a></li>
            <?php if(auth()->guard()->check()): ?>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Logout</a>
                </li>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <li>
                    <?php if(Route::currentRouteName() == 'login'): ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Sign Up</a>
                    <?php elseif(Route::currentRouteName() == 'register'): ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login</a>
                    <?php endif; ?>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</header><?php /**PATH C:\xampp\htdocs\my_billapp\resources\views/partials/navbar.blade.php ENDPATH**/ ?>