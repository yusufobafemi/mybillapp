<div class="card upcoming-bills-card">
    <div class="card-header">
        <h3>Upcoming Bills</h3>
        <button class="btn small-btn"><i class="fas fa-plus"></i> Add</button>
    </div>
    <div class="bills-list">
        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bill-item">
                <div class="bill-icon <?php echo e($bill['class']); ?>">
                    <i class="<?php echo e($bill['icon']); ?>"></i>
                </div>
                <div class="bill-details">
                    <h4><?php echo e($bill['title']); ?></h4>
                    <p><?php echo e($bill['due']); ?></p>
                </div>
                <div class="bill-amount">
                    <span><?php echo e($bill['amount']); ?></span>
                    <button class="btn small-btn primary-btn">Pay Now</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_billapp\resources\views/components/upcoming-bills.blade.php ENDPATH**/ ?>