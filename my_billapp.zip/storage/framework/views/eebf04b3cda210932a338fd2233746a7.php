<tr class="transaction-row">
    <td>
        <div class="cell-content">
            <span class="date"><?php echo e($date); ?></span>
            <span class="time"><?php echo e($time); ?></span>
        </div>
    </td>
    <td>
        <div class="cell-content">
            <span class="transaction-id"><?php echo e($transactionId); ?></span>
        </div>
    </td>
    <td>
        <div class="cell-content">
            <div class="transaction-icon-small <?php echo e($iconClass); ?>">
                <i class="fas <?php echo e($icon); ?>"></i>
            </div>
            <div class="description-text">
                <span class="primary-text"><?php echo e($primaryText); ?></span>
                <span class="secondary-text"><?php echo e($secondaryText); ?></span>
            </div>
        </div>
    </td>
    <td>
        <div class="cell-content">
            <span class="category-badge <?php echo e($categoryClass); ?>"><?php echo e($category); ?></span>
        </div>
    </td>
    <td>
        <div class="cell-content">
            <span class="amount <?php echo e($amountClass); ?>"><?php echo e($amount); ?></span>
        </div>
    </td>
    <td>
        <div class="cell-content">
            <span class="status-badge <?php echo e($statusClass); ?>"><?php echo e($status); ?></span>
        </div>
    </td>
    <td>
        <div class="cell-content">
            <button class="btn icon-btn small-btn"><i class="fas fa-receipt"></i></button>
            <?php if($status !== 'Failed'): ?>
                <button class="btn icon-btn small-btn"><i class="fas fa-redo"></i></button>
            <?php endif; ?>
        </div>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\my_billapp\resources\views/components/transaction-row.blade.php ENDPATH**/ ?>