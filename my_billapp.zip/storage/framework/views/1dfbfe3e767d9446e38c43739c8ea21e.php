<div class="card quick-actions">
    <div class="card-header">
        <h3>Quick Actions</h3>
    </div>
    <div class="actions-grid">
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="action-item">
                <div class="action-icon <?php echo e($action['class']); ?>">
                    <i class="<?php echo e($action['icon']); ?>"></i>
                </div>
                <span><?php echo e($action['name']); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_billapp\resources\views/components/quick-actions.blade.php ENDPATH**/ ?>